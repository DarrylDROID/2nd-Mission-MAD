package model;

import android.os.Parcel;
import android.os.Parcelable;

public class User implements Parcelable {

    private String fullname, address;
    private int age;

    public User() {
        this.fullname = "";
        this.age = 0;
        this.address = "";
    }

    public User(String fullname, int age, String address) {
        this.fullname = fullname;
        this.age = age;
        this.address = address;
    }


    protected User(Parcel in) {
        fullname = in.readString();
        age = in.readInt();
        address = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fullname);
        dest.writeInt(age);
        dest.writeString(address);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<User> CREATOR = new Creator<User>() {
        @Override
        public User createFromParcel(Parcel in) {
            return new User(in);
        }

        @Override
        public User[] newArray(int size) {
            return new User[size];
        }
    };

    public String getFullName() {

        return fullname;
    }

    public void setFullName(String fullname) {

        this.fullname = fullname;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {

        return address;
    }

    public void setAddress(String address) {

        this.address = address;
    }
}
