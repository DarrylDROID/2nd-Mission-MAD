package com.example.a2ndmissionmad;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.textfield.TextInputLayout;

import java.util.regex.Pattern;

import model.User;

public class AddUser extends AppCompatActivity {

    private TextInputLayout fullname, age, address;
    private Button save;
    private ImageView back;
    private Boolean max;
    private Toolbar toolbar_title;
    public User user;
    public int position;
    public TextView toolbar_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_user);

        user = getIntent().getParcelableExtra("data");
        position = getIntent().getIntExtra("position", 0);

        initView();
        setListener();
    }

    private void setListener() {
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user != null) {

                    editData();
                } else {
                    addData();
                    final LoadingDialog loadingDialog = new LoadingDialog(AddUser.this);
                    loadingDialog.startLoadingDialog();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            finish();
                        }
                    }, 3000);
                }
            }
        });
    }

    private void initView() {
        fullname = findViewById(R.id.fullname);
        age = findViewById(R.id.age);
        address = findViewById(R.id.address);
        save = findViewById(R.id.save);
        toolbar_text = findViewById(R.id.toolbar_text);
        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        fullname.getEditText().addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String nama = fullname.getEditText().getText().toString().trim();

                Pattern TITLE_PATTERN = Pattern.compile("[a-zA-Z0-9\\!\\@\\#\\$]{0,20}");

                if (nama.length() < 0 || nama.length() > 30) {
                    fullname.setError("Hanya menerima maksimal 30 karakter");
                    max = false;
                } else {
                    fullname.setError("");
                    max = true;
                }
                save.setEnabled(!nama.isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        save = (Button) findViewById(R.id.save);
        showData();
    }

    public void showData() {
        if (user != null) {
            fullname.getEditText().setText(user.getFullName());
            age.getEditText().setText(String.valueOf(user.getAge()));
            address.getEditText().setText(user.getAddress());
            toolbar_text.setText("Edit User Data");
            save.setText("Update Data");
        } else {
            toolbar_text.setText("Add User Data");
            save.setText("Save Data");
        }
    }

    public void editData() {
        String nama = fullname.getEditText().getText().toString().trim();
        int umur = Integer.parseInt(age.getEditText().getText().toString().trim());
        String alamat = address.getEditText().getText().toString().trim();
        User temp = new User(nama, umur, alamat);

        Intent intent = new Intent(this, RecyclerviewActivity.class);
        intent.putExtra("userEdit", temp);
        intent.putExtra("position", position);
        startActivity(intent);
        finish();
    }

    public void addData() {
        String nama = fullname.getEditText().getText().toString().trim();
        int umur = Integer.parseInt(age.getEditText().getText().toString().trim());
        String alamat = address.getEditText().getText().toString().trim();
        User temp = new User(nama, umur, alamat);

        Intent intent = new Intent();
        intent.putExtra("userAdd", temp);
        setResult(200, intent);
        finish();
    }
}