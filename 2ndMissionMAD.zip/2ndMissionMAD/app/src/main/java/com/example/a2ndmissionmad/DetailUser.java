package com.example.a2ndmissionmad;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import model.User;
import model.UserData;

public class DetailUser extends AppCompatActivity {

    public User user;
    public int position;
    public ArrayList<User> listUser = UserData.saveList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_user);

        user = getIntent().getParcelableExtra("data");
        position = getIntent().getIntExtra("position", 0);
        TextView namalengkap = findViewById(R.id.namalengkap);
        TextView umur = findViewById(R.id.hasilumur);
        TextView alamat = findViewById(R.id.hasilalamat);
        Button edit = findViewById(R.id.edit);
        Button delete = findViewById(R.id.delete);

        namalengkap.setText(user.getFullName());
        umur.setText(String.valueOf(user.getAge()));
        alamat.setText(user.getAddress());

        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navigateToEditPage();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertMessage();
            }
        });
    }

    public void navigateToEditPage() {
        Intent intent = new Intent(this, AddUser.class);
        intent.putExtra("data", user);
        intent.putExtra("position", position);
        startActivity(intent);
        finish();
    }

    public void alertMessage() {
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case DialogInterface.BUTTON_POSITIVE:

                        listUser.remove(position);
                        Log.d("test", String.valueOf(position));

                        Toast.makeText(DetailUser.this, "Delete Success",
                                Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(DetailUser.this, RecyclerviewActivity.class);
                        startActivity(intent);

//                        loading.startLoadingDialog();
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {

                            }
                        }, 5000);
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        dialog.dismiss();
                }
            }
        };

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmation!");
        builder.setMessage("Are you sure want to delete " + listUser.get(position).getFullName() + " data?")
                .setPositiveButton("Yes", dialogClickListener)
                .setNegativeButton("No", dialogClickListener).show();
    }
}
