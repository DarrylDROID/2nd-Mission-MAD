package com.example.a2ndmissionmad;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import model.User;

public class CardViewAdapter extends RecyclerView.Adapter<CardViewAdapter.UserViewHolder> {

    private ArrayList<User> listUser;
    protected Context context;

    public CardViewAdapter(ArrayList<User> listUser, Context context) {
        this.context = context;
        this.listUser = listUser;
    }

    @NonNull
    @Override
    public UserViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.cardview_user, parent, false);
        return new UserViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UserViewHolder holder, int position) {
        holder.card_nama.setText(listUser.get(position).getFullName());
        holder.card_umur.setText(String.valueOf(listUser.get(position).getAge()));
        holder.card_alamat.setText(listUser.get(position).getAddress());

    }

    @Override
    public int getItemCount() {
        return listUser.size();
    }

    public class UserViewHolder extends RecyclerView.ViewHolder {

        private TextView card_nama, card_umur, card_alamat;
        private ImageView card_image_item;
        private CardView card_display;

        public UserViewHolder(@NonNull View itemView) {
            super(itemView);
            card_nama = itemView.findViewById(R.id.card_nama);
            card_alamat = itemView.findViewById(R.id.card_alamat);
            card_umur = itemView.findViewById(R.id.card_umur);
            card_image_item = itemView.findViewById(R.id.card_image_item);
            card_display = itemView.findViewById(R.id.card_display);

            card_display.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(context, DetailUser.class);
                    intent.putExtra("data", listUser.get(getAdapterPosition()));
                    intent.putExtra("position", getAdapterPosition());
                    context.startActivity(intent);
                }
            });
        }
    }
}