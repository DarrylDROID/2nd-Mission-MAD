package com.example.a2ndmissionmad;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

import model.User;
import model.UserData;

public class RecyclerviewActivity extends AppCompatActivity {

    private RecyclerView recyclerView_recyclerView;
    private ArrayList<User> listUser = UserData.saveList;
    private CardViewAdapter adapter;
    private FloatingActionButton recyclerView_FAB_add;
    private TextView main_text_nodata;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recycler_view);
        initView();
        setupRecyclerView();
        addDummyData();
        getUpdatedData();
        setListener();
    }

    public void getUpdatedData() {
        int position = getIntent().getIntExtra("position", 0);

        User user = getIntent().getParcelableExtra("userEdit");
        if (user != null) {
            listUser.remove(position);
            listUser.add(position, user);
            adapter.notifyItemChanged(position);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        main_text_nodata = findViewById(R.id.main_text_nodata);

        if (requestCode == 1) {
            if (resultCode == 200) {
                User userAdd = data.getParcelableExtra("userAdd");
                listUser.add(userAdd);
                adapter.notifyDataSetChanged();
            }
        }
                if (!listUser.isEmpty()) {
                    main_text_nodata.setVisibility(View.GONE);
        }
    }

    private void setListener() {
        recyclerView_FAB_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getBaseContext(), AddUser.class);
                startActivityForResult(intent, 1);
            }
        });
    }

    private void addDummyData() {
        adapter.notifyDataSetChanged();
    }

    private void setupRecyclerView() {
        RecyclerView.LayoutManager manager = new LinearLayoutManager(getBaseContext());
        recyclerView_recyclerView.setLayoutManager(manager);
        recyclerView_recyclerView.setAdapter(adapter);
    }

    private void initView() {
        recyclerView_recyclerView = findViewById(R.id.recyclerView_recyclerView);
        adapter = new CardViewAdapter(listUser, this);
        recyclerView_FAB_add = findViewById(R.id.recyclerView_FAB_add);
    }

    private static final int TIME_INTERVAL = 2000;
    private long doubleClick;

    @Override
    public void onBackPressed() {
        if (doubleClick + TIME_INTERVAL > System.currentTimeMillis()) {
            super.onBackPressed();
            return;
        } else {
            Toast.makeText(getBaseContext(), "Press back again to exit", Toast.LENGTH_SHORT).show();
        }
        doubleClick = System.currentTimeMillis();
    }
}
